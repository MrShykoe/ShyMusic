package com.shymusic.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF0E0E12)
val Panel = Color(0xFF15151C)
val Field = Color(0xFF1A1A22)
val Muted = Color(0xFF9A9AA8)
val Accent = Color(0xFFB69CFF)

@Composable
fun ShyTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            onPrimary = Color(0xFF1B1030),
            background = Bg,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White,
            surfaceVariant = Field,
            onSurfaceVariant = Muted,
            secondaryContainer = Color(0xFF2A2440),
            onSecondaryContainer = Color.White
        ),
        content = content
    )
}
