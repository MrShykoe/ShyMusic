package com.shymusic.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.shymusic.app.data.TrackItem
import com.shymusic.app.data.formatTime

@Composable
fun MainScreen(vm: MainViewModel) {
    val s by vm.state.collectAsStateWithLifecycle()

    Scaffold(
        containerColor = Bg,
        bottomBar = { if (s.hasMedia) MiniPlayer(s, vm) }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            SearchRow(s, vm)

            Box(Modifier.fillMaxSize()) {
                when {
                    s.loading -> CircularProgressIndicator(Modifier.align(Alignment.Center), color = Accent)
                    s.results.isEmpty() -> Text(
                        s.error ?: "Введи название трека или артиста",
                        color = Muted, fontSize = 15.sp,
                        modifier = Modifier.align(Alignment.Center).padding(24.dp)
                    )
                    else -> {
                        LazyColumn(Modifier.fillMaxSize()) {
                            if (s.error != null) item {
                                Text(s.error!!, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(16.dp))
                            }
                            itemsIndexed(s.results, key = { _, t -> t.url }) { i, t ->
                                TrackRow(t) { vm.play(i) }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchRow(s: UiState, vm: MainViewModel) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        OutlinedTextField(
            value = s.query,
            onValueChange = vm::setQuery,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("Поиск музыки", color = Muted) },
            leadingIcon = { Icon(Icons.Filled.Search, null, tint = Muted) },
            trailingIcon = {
                if (s.query.isNotEmpty()) IconButton(onClick = { vm.setQuery("") }) {
                    Icon(Icons.Filled.Close, "Очистить", tint = Muted)
                }
            },
            shape = RoundedCornerShape(16.dp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { vm.search() }),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Field,
                unfocusedContainerColor = Field,
                focusedBorderColor = Accent,
                unfocusedBorderColor = Color0
            )
        )
        FilterChip(
            selected = s.songsOnly,
            onClick = { vm.setSongsOnly(!s.songsOnly) },
            label = { Text("Только песни (YouTube Music)") },
            modifier = Modifier.padding(top = 8.dp)
        )
    }
}

private val Color0 = androidx.compose.ui.graphics.Color(0xFF2A2A35)

@Composable
private fun TrackRow(t: TrackItem, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = t.coverUrl, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.size(52.dp).clip(RoundedCornerShape(8.dp)).background(Field)
        )
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 15.sp)
            Text(t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = Muted)
        }
        Text(t.durationText, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun MiniPlayer(s: UiState, vm: MainViewModel) {
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableStateOf(0f) }
    val frac = if (s.durationMs > 0) (s.positionMs.toFloat() / s.durationMs).coerceIn(0f, 1f) else 0f

    Column(
        Modifier.fillMaxWidth().background(Panel).navigationBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(
                model = s.nowCover, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.size(48.dp).clip(RoundedCornerShape(8.dp)).background(Field)
            )
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(s.nowTitle, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                Text(
                    if (s.buffering) "Загружаю…" else s.nowArtist,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = Muted
                )
            }
            IconButton(onClick = vm::prev) { Icon(Icons.Rounded.SkipPrevious, "Назад", tint = MaterialTheme.colorScheme.onSurface) }
            IconButton(onClick = vm::togglePlay) {
                Icon(
                    if (s.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    "Пауза/играть", tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(34.dp)
                )
            }
            IconButton(onClick = vm::next) { Icon(Icons.Rounded.SkipNext, "Вперёд", tint = MaterialTheme.colorScheme.onSurface) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(formatTime((if (dragging) dragValue * s.durationMs else s.positionMs.toFloat()).toLong()), color = Muted, fontSize = 11.sp)
            Slider(
                value = if (dragging) dragValue else frac,
                onValueChange = { dragging = true; dragValue = it },
                onValueChangeFinished = { vm.seekToFraction(dragValue); dragging = false },
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
            )
            Text(formatTime(s.durationMs), color = Muted, fontSize = 11.sp)
        }
    }
}
