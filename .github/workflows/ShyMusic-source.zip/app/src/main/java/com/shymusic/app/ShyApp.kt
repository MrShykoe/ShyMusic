package com.shymusic.app

import android.app.Application
import com.shymusic.app.data.DownloaderImpl
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import java.util.Locale

class ShyApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val locale = Locale.getDefault()
        NewPipe.init(
            DownloaderImpl(),
            Localization.fromLocale(locale),
            ContentCountry(locale.country.ifEmpty { "US" })
        )
    }
}
