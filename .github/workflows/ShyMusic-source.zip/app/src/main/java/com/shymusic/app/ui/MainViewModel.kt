package com.shymusic.app.ui

import android.app.Application
import android.content.ComponentName
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.shymusic.app.PlaybackService
import com.shymusic.app.data.TrackItem
import com.shymusic.app.data.YouTubeSource
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.guava.await
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.coroutines.cancellation.CancellationException

data class UiState(
    val query: String = "",
    val songsOnly: Boolean = false,
    val loading: Boolean = false,
    val error: String? = null,
    val results: List<TrackItem> = emptyList(),
    val hasMedia: Boolean = false,
    val nowTitle: String = "",
    val nowArtist: String = "",
    val nowCover: String? = null,
    val isPlaying: Boolean = false,
    val buffering: Boolean = false,
    val positionMs: Long = 0,
    val durationMs: Long = 0
)

class MainViewModel(private val app: Application) : AndroidViewModel(app) {
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var controller: MediaController? = null
    private var searchJob: Job? = null

    init {
        viewModelScope.launch {
            try {
                val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
                val c = MediaController.Builder(app, token).buildAsync().await()
                controller = c
                c.addListener(object : Player.Listener {
                    override fun onEvents(player: Player, events: Player.Events) = sync(player)
                    override fun onPlayerError(error: PlaybackException) {
                        _state.update { it.copy(error = "Не получилось включить трек: ${error.cause?.message ?: error.message}") }
                    }
                })
                sync(c)
                while (isActive) {
                    delay(500)
                    val p = controller ?: break
                    if (p.isPlaying) _state.update { it.copy(positionMs = p.currentPosition.coerceAtLeast(0)) }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(error = "Плеер не запустился: ${e.message}") }
            }
        }
    }

    private fun sync(p: Player) {
        val item = p.currentMediaItem
        val dur = p.duration
        _state.update {
            it.copy(
                hasMedia = item != null,
                nowTitle = item?.mediaMetadata?.title?.toString() ?: "",
                nowArtist = item?.mediaMetadata?.artist?.toString() ?: "",
                nowCover = item?.mediaMetadata?.artworkUri?.toString(),
                isPlaying = p.isPlaying,
                buffering = p.playbackState == Player.STATE_BUFFERING,
                positionMs = p.currentPosition.coerceAtLeast(0),
                durationMs = if (dur == C.TIME_UNSET) 0 else dur
            )
        }
    }

    fun setQuery(q: String) = _state.update { it.copy(query = q) }
    fun setSongsOnly(v: Boolean) = _state.update { it.copy(songsOnly = v) }

    fun search() {
        val q = _state.value.query.trim()
        if (q.isEmpty()) return
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null) }
            try {
                val r = YouTubeSource.search(q, _state.value.songsOnly)
                _state.update {
                    it.copy(loading = false, results = r, error = if (r.isEmpty()) "Ничего не найдено" else null)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(loading = false, error = "Ошибка поиска: ${e.message}") }
            }
        }
    }

    fun play(index: Int) {
        val c = controller ?: return
        val items = _state.value.results.map { t ->
            MediaItem.Builder()
                .setMediaId(t.url)
                .setUri(t.url)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(t.title)
                        .setArtist(t.artist)
                        .setArtworkUri(t.coverUrl?.let { Uri.parse(it) })
                        .build()
                )
                .build()
        }
        _state.update { it.copy(error = null) }
        c.setMediaItems(items, index, 0L)
        c.prepare()
        c.play()
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() { controller?.seekToNextMediaItem() }
    fun prev() { controller?.seekToPrevious() }

    fun seekToFraction(f: Float) {
        val c = controller ?: return
        val d = _state.value.durationMs
        if (d > 0) c.seekTo((d * f).toLong())
    }

    override fun onCleared() {
        controller?.release()
        controller = null
        super.onCleared()
    }
}
