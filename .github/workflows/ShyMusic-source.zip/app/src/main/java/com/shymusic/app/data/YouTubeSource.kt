package com.shymusic.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.search.SearchInfo
import org.schabi.newpipe.extractor.services.youtube.linkHandler.YoutubeSearchQueryHandlerFactory
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.util.concurrent.ConcurrentHashMap

// YouTube без ключей, через NewPipeExtractor (неофициально: если сломается, обновляем версию библиотеки).
object YouTubeSource {
    private val service get() = ServiceList.YouTube
    private val urlCache = ConcurrentHashMap<String, Pair<String, Long>>()

    suspend fun search(query: String, songsOnly: Boolean): List<TrackItem> = withContext(Dispatchers.IO) {
        val filter = if (songsOnly) YoutubeSearchQueryHandlerFactory.MUSIC_SONGS
        else YoutubeSearchQueryHandlerFactory.VIDEOS
        val handler = service.searchQHFactory.fromQuery(query, listOf(filter), "")
        val info = SearchInfo.getInfo(service, handler)
        info.relatedItems
            .filterIsInstance<StreamInfoItem>()
            .map {
                TrackItem(
                    url = it.url,
                    title = it.name,
                    artist = (it.uploaderName ?: "").removeSuffix(" - Topic"),
                    coverUrl = it.thumbnails.maxByOrNull { img -> img.height }?.url,
                    durationSec = it.duration
                )
            }
    }

    // Ссылка на настоящий аудиопоток. Вызывается из плеера в фоновом потоке.
    fun resolveAudioUrl(videoUrl: String): String {
        val now = System.currentTimeMillis()
        urlCache[videoUrl]?.let { (url, at) -> if (now - at < 3 * 3600_000L) return url }

        val info = StreamInfo.getInfo(service, videoUrl)
        val best = info.audioStreams
            .filter { it.isUrl && it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }
            .maxByOrNull { it.averageBitrate }
            ?: throw IllegalStateException("Нет подходящего аудиопотока")
        val url = best.content
        urlCache[videoUrl] = url to now
        return url
    }
}
